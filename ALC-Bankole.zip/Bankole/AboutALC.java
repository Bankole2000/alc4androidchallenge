package com.example.alc_p1ch1;

import android.net.http.SslError;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
//import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.SslErrorHandler;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class AboutALC extends AppCompatActivity {
    String urlStr = "https://andela.com/alc/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_alc);


        WebView webView = findViewById(R.id.webview_abt_alc);
        webView.getSettings().setJavaScriptEnabled(true);
        //webView.getSettings().setDomStorageEnabled(true);

        webView.setWebViewClient(new WebViewClient());


        //WebSettings webSettings = webView.getSettings();
        //webView.setWebChromeClient(new WebChromeClient());
        //webSettings.setUseWideViewPort(true);
       //webSettings.setLoadWithOverviewMode(true);

        webView.loadUrl(urlStr);


    }
}
