package com.example.alc_p1ch1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private Button bnAboutAlc;
    private Button bnMyProfile;
    //private Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
         //intent = new Intent(this,AboutALC.class);



        bnAboutAlc = findViewById(R.id.bn_about_alc);
        bnAboutAlc.setOnClickListener(this);


        bnMyProfile = findViewById(R.id.bn_my_profile);
        bnMyProfile.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()){

            case R.id.bn_about_alc:
                startActivity(new Intent(this,AboutALC.class));
                break;

            case R.id.bn_my_profile:
                startActivity(new Intent(this,MyProfile.class));
                break;

        }

    }
}
